package com.kosmo.kosmoapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.kosmo.kosmoapp.service.KosmoService;
import com.kosmo.kosmoapp.service.MemberDTO;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class LoginActivity extends AppCompatActivity {


    private EditText id;
    private EditText pwd;
    private Button btnLogin;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        //타이틀바 색상 변경-자바코드
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(0x99FF0000));

        //서버 연동전 화면 전환을 위한 테스트 코드
        /*
        Handler handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent);
                //전환된 화면(MainActivity)Destroy시 로그인 화면도 Destroy하기
                //XML에서 android:noHistory="true"처리
            }
        };
        //1초 지연후 LoginActivity로 전환
        handler.sendEmptyMessageDelayed(0,1000);
        */
        //위젯 얻기]
        initView();
        //버튼 배경 투명처리
        btnLogin.getBackground().setAlpha(170);
        //버튼에 리스너 부착
        btnLogin.setOnClickListener(listener);
    }///////////////onCreat
    //버튼 이벤트 처리]
    private View.OnClickListener listener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {


            //프로그래스바용 다이얼로그 생성]
            //빌더 생성 및 다이얼로그창 설정
            AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
            builder.setCancelable(false);
            builder.setView(R.layout.progress);
            builder.setIcon(android.R.drawable.ic_menu_compass);
            builder.setTitle("로그인");

            //빌더로 다이얼로그창 생성
            AlertDialog progressDialog = builder.create();
            progressDialog.show();


            String username = id.getText().toString();
            String password = pwd.getText().toString();
            Retrofit retrofit =new Retrofit.Builder()
                    .addConverterFactory(JacksonConverterFactory.create())
                    .baseUrl("http://192.168.0.25:9090/")
                    .build();
            KosmoService kosmoService=retrofit.create(KosmoService.class);
            Call<MemberDTO> call= kosmoService.join(username,password);

            call.enqueue(new Callback<MemberDTO>() {
                @Override
                public void onResponse(Call<MemberDTO> call, Response<MemberDTO> response) {
                    Log.i("com.kosmo.kosmoapp","상태코드:"+response.code());
                    if(response.isSuccessful()){
                        MemberDTO member = response.body();
                        Log.i("com.kosmo.kosmoapp","결과값:"+member.getUsername());
                        if(member.getUsername() !=null) {
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);
                            //finish()불필요-NO_HISTORY로 설정했기때문에(매니페스트에서)
                            //아이디 비번저장
                            SharedPreferences preferences = getSharedPreferences("loginInfo", MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();

                            editor.putString("id", member.getUsername());
                            editor.putString("pwd", member.getPassword());
                            editor.commit();
                        }
                        else {
                            //Toast.makeText(LoginActivity.this, "아이디와 비번이 일치하지 않아요", Toast.LENGTH_SHORT).show();
                            new AlertDialog.Builder(LoginActivity.this)
                                    .setIcon(android.R.drawable.ic_dialog_email)
                                    .setTitle("로그인 결과")
                                    .setMessage("아이디와 비번 불일치")
                                    .setPositiveButton("확인",null)
                                    .show();
                        }
                    }
                    else{//200번 아닌거

                    }
                    SystemClock.sleep(2000);//속도가 너무 빨라서 다이얼로그창 실행되는 보여주기 위함
                    progressDialog.dismiss();
                }
                @Override
                public void onFailure(Call<MemberDTO> call, Throwable t) {}
            });


        }
    };//////////////////OnClickListener
    private void initView() {
        id = (EditText) findViewById(R.id.id);
        pwd = (EditText) findViewById(R.id.pwd);
        btnLogin = (Button) findViewById(R.id.btn_login);
    }
}//////////class
