package com.kosmo.kosmoapp.view;

import android.content.Context;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kosmo.kosmoapp.R;
import com.kosmo.kosmoapp.adapter.Fragment1Adapter;
import com.kosmo.kosmoapp.service.KosmoService;
import com.kosmo.kosmoapp.service.PhotoDTO;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Vector;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;


//1]Fragement상속
//※androidx.fragment.app.Fragment 상속
public class Fragment_1 extends Fragment {

    //리사이클러뷰에 뿌려질 데이타  선언]
    private List<PhotoDTO> items = new Vector<>();
    private RecyclerView recyclerView;
    private Fragment1Adapter adapter;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Log.i("com.kosmo.kosmoapp","onAttach:1");
    }

    //2]onCreateView()오버 라이딩
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.i("com.kosmo.kosmoapp","onCreateView:1");
        //레이아웃 전개]
        View view = inflater.inflate(R.layout.tablayout_1,container,false);
        //아이디로 리소스 가져올때:view.findViewById()
        //리사이클러 뷰 얻기]
        recyclerView=view.findViewById(R.id.recyclerView);

        //데이타는 스레드로 원격 서버에서 받아 온다
        Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl("http://192.168.0.25:9090/")
                    .addConverterFactory(JacksonConverterFactory.create()).build();
        KosmoService kosmoService=retrofit.create(KosmoService.class);
        Call<List<PhotoDTO>> call= kosmoService.photos();
        call.enqueue(new Callback<List<PhotoDTO>>() {
            @Override
            public void onResponse(Call<List<PhotoDTO>> call, Response<List<PhotoDTO>> response) {
                Log.i("com.kosmo.kosmoapp","상태코드:"+response.code());
                if(response.isSuccessful()){
                    items = response.body();
                    //어댑터 생성]
                    adapter=new Fragment1Adapter(getContext(),items);
                    //리스트뷰와 어댑터 연결]
                    recyclerView.setAdapter(adapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                    Log.i("com.kosmo.kosmoapp","목록 총 갯수:"+String.valueOf(response.body().size()));
                }
                else{

                }
            }
            @Override
            public void onFailure(Call<List<PhotoDTO>> call, Throwable t) {

            }
        });
        return view;
    }/////////

}
