package com.kosmo.kosmoapp.view;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.kosmo.kosmoapp.MainActivity;
import com.kosmo.kosmoapp.R;
import com.kosmo.kosmoapp.service.KosmoService;


import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;


//1]Fragement상속
//※androidx.fragment.app.Fragment 상속
public class Fragment_3 extends Fragment {

    public static Button btnCamera;
    private Button btnGallery;
    private ImageView imageView;

    String photoImagePath;
    private Context context;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;

        Log.i("com.kosmo.kosmoapp","onAttach:3");
    }

    //2]onCreateView()오버 라이딩
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.i("com.kosmo.kosmoapp","onCreateView:3");
        View view=inflater.inflate(R.layout.tablayout_3,null,false);
        btnCamera = view.findViewById(R.id.btnCamera);
        btnGallery= view.findViewById(R.id.btnGallery);
        imageView = view.findViewById(R.id.imageView);
        //카메라 버튼
        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cameraLauncher.launch(intent);
            }
        });
        //갤러리 버튼
        btnGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");
                galleryLauncher.launch(intent);
            }
        });

        return view;
    }/////////

    //API LEVEL 30 이후 코딩 방식 - startActivityForResult() Deprecated / onActivityResult()오버라이딩 불필요

    ActivityResultLauncher<Intent> cameraLauncher= registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    switch(result.getResultCode()){
                        case Activity.RESULT_OK:
                            Intent data=result.getData();
                            if(data== null){
                                Toast.makeText(context,"카메라로 사진 찍기 실패",Toast.LENGTH_SHORT).show();
                                return;
                            }
                            Bitmap bmp=(Bitmap)data.getExtras().get("data");


                            //아래는 용량이 클 경우 OutOfMemoryException 발생이 예상되어 압축
                            ByteArrayOutputStream stream = new ByteArrayOutputStream();
                            bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                            byte[] byteArray = stream.toByteArray();
                            // convert byte array to Bitmap
                            Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                            //압축된 이미지를 이미지뷰에표시
                            imageView.setImageBitmap(bitmap);

                            //압축이 안된 이미지를 이미지뷰에 표시
                            //imageView.setImageBitmap(bmp);

                            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");

                            File file=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                            photoImagePath=file.getAbsolutePath()+File.separator+dateFormat.format(new Date())+"_camera.png";

                            file = new File(photoImagePath);

                            ///갤러리에 촬영한 사진 추가하기
                            BufferedOutputStream bos = null;
                            try {
                                bos = new BufferedOutputStream(
                                        new FileOutputStream(file));

                                bmp.compress(Bitmap.CompressFormat.PNG,100,bos);//이미지가 용량이 클 경우
                                //OutOfMemoryException 발생할수 있음.그래서 압축
                                //사진을 앨범에 보이도록 갤러리앱에 방송을 보내기
                                getActivity().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));

                                bos.flush();
                                bos.close();


                                sendImageToServer(file);

                            }
                            catch(Exception e){e.printStackTrace();}
                            Log.i("com.kosmo.kosmoapp",photoImagePath);
                            break;
                    }
                }
            });
    ActivityResultLauncher<Intent> galleryLauncher= registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    switch(result.getResultCode()){
                        case Activity.RESULT_OK:
                            Intent data=result.getData();
                            if(data== null){
                                Toast.makeText(context,"이미지를 가져올수 없어요",Toast.LENGTH_SHORT).show();
                                return;
                            }
                            //갤러리에 있는 이미지 선택
                            Uri selectedImageUri=data.getData();
                            //선택된 이미지의 Uri로 이미지뷰에 표시
                            imageView.setImageURI(selectedImageUri);
                            break;
                    }
                }
            });


    private void sendImageToServer(File file){
        Retrofit retrofit = new Retrofit.Builder()
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .baseUrl("http://192.168.0.25:9090/")
                    .build();
        KosmoService kosmoService= retrofit.create(KosmoService.class);
        RequestBody title = RequestBody.create(MediaType.parse("text/plain"),"Upload Image!!!");
        RequestBody postedFile = RequestBody.create(MediaType.parse("multipart/form-data"),file);
        MultipartBody.Part attachFile = MultipartBody.Part.createFormData("attachFile",file.getName(),postedFile);
        Call<String> call=kosmoService.upload(title,attachFile);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if(response.isSuccessful()){
                    Log.i("com.kosmo.kosmoapp",response.body());
                }
                else{
                    Log.i("com.kosmo.kosmoapp",response.errorBody().toString());
                }
            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Log.i("com.kosmo.kosmoapp","onFailure:"+t.getMessage());
            }
        });


    }


}
