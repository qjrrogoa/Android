package com.kosmo.kosmoapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.kosmo.kosmoapp.R;

import com.kosmo.kosmoapp.service.PhotoDTO;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Fragment1Adapter extends RecyclerView.Adapter<Fragment1Adapter.ViewHolder> {

    private Context context;
    private List<PhotoDTO> items;
    //인자 생성자를 통해 Context및 데이타 받기
    public Fragment1Adapter(Context context, List<PhotoDTO> items) {
        this.context = context;
        this.items = items;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        //카드뷰 사용시 반드시 parent는 지정해야 한다
        //아래는 사용하지 말기
        //View itemView=View.inflate(context,R.layout.json_item_layout,null);
        //아래 코드 사용
        View itemView = LayoutInflater.from(context).inflate(R.layout.tabmenu1_item_layout,parent,false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull  ViewHolder holder, int position) {
        PhotoDTO item=items.get(position);

        holder.itemText.setText(item.getText());
        //https://square.github.io/picasso/
        Picasso.get().load(item.getImageUrl()).into(holder.itemIcon);
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,items.get(position).getImageUrl(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }//////////////

    class ViewHolder extends RecyclerView.ViewHolder{
        TextView itemText;
        ImageView itemIcon;
        CardView cardView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemText = itemView.findViewById(R.id.itemtext);
            itemIcon = itemView.findViewById(R.id.itemicon);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }


}
